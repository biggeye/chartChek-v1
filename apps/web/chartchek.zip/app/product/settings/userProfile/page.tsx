import UserProfile from '~/components/settings/UserProfile';

export default function UserProfileSettings() {
  return <UserProfile />;
}