import { ReactNode } from 'react';

export default function ComplianceLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
} 